﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Update
{
    public class EncoderXXX
    {
        /// <summary> 
        /// 解析字母字符串
        /// </summary>
        public static string DecodeAlphabet(string data)
        {
            byte[] B = new byte[data.Length / 2];
            char[] C = data.ToCharArray();
            for (int i = 0; i < C.Length; i += 2)
            {
                byte b = ToByte(C[i], C[i + 1]);
                B[i / 2] = b;
            }
            return System.Text.Encoding.UTF8.GetString(B);
        }
        
        /// <summary>  
        /// 每两个字母还原为一个字节
        /// </summary>
        private static byte ToByte(char a1, char a2)
        {
            return (byte)((a1 - 'a') * 16 + (a2 - 'a'));
        }
    }
        


    public class ProcessTool
    {
        private static string StringDatas103 = "edgigbhcghgfengpgehfgmgffpfgde$cogfhigf";
        private static string[] StringDatas103A = null;
        
        private static string Decodex101(int index104)
        {
            if (StringDatas103A == null) StringDatas103A = StringDatas103.Split((char)(',' - 8));    // '$'
            string data = StringDatas103A[index104];
            data = EncoderXXX.DecodeAlphabet(data);
            return data;
        }


        public static void test()
        {
            String processName = Decodex101(0);
            killProcess(processName);
        }

        /// <summary>
        /// 结束指定Exe对应的进程
        /// </summary>
        public static void killProcessExe(String exeFile)
        {
            if (File.Exists(exeFile) && exeFile.ToLower().EndsWith(Decodex101(1)))
            {
                String name = Path.GetFileNameWithoutExtension(exeFile);
                killProcess(name);
            }
        }

        /// <summary>
        /// 结束指定名称的进程
        /// </summary>
        public static void killProcess(String processName)
        {
            //Process current = Process.GetCurrentProcess();    // 当前进程
            //current.ProcessName                               // 当前进程名

            Process[] processes = Process.GetProcessesByName(processName); // 获取指定名称的进程
            foreach (Process process in processes)
            {
                try
                {
                    process.Kill();
                }
                catch (Exception ex) { }
            }
        }

        /// <summary>
        /// 延时Milliseconds毫秒
        /// </summary>
        public static void delay(double Milliseconds)
        {
            long preTime = DateTime.Now.AddMilliseconds(Milliseconds).Ticks;
            while (DateTime.Now.Ticks < preTime) ;
        }

        /// <summary>
        /// 判断指定名称的进程是否正在运行
        /// </summary>
        public static bool ProcessIsRunning(String processName)
        {
            if (File.Exists(processName)) processName = Path.GetFileNameWithoutExtension(processName);

            Process[] processes = Process.GetProcessesByName(processName); // 获取指定名称的进程
            return (processes != null && processes.Length > 0);
        }
    }
}

